import { createCustomElement, actionTypes } from "@servicenow/ui-core";
import snabbdom from "@servicenow/ui-renderer-snabbdom";
import styles from "./styles.scss";
import style from "./level.scss";
import { createHttpEffect } from "@servicenow/ui-effect-http";

const { COMPONENT_BOOTSTRAPPED } = actionTypes;

const levelThreshold = {
	Beginner: 50,
	Intermediate: 100,
	Advanced: 200,
	Master: 350,
	Expert: 500,
};

const Images = {
    Beginner: '7ee72dfb83f29210cccd5d10feaad3a5',
	Intermediate: 'fe736d3783f29210cccd5d10feaad32d',
	Advanced: "ec66a97b83f29210cccd5d10feaad3ce",
	Master: "d9d5af5783b61210cccd5d10feaad3c5",
	Expert: "4cb56b5783b61210cccd5d10feaad371",
}

const view = (state, { updateState }) => {
    const { TechnicianProfile, progressBarWidth } = state;

    var imagId = ''

    switch (state.TechnicianProfile.level) {
        case "Beginner":
            imagId = Images.Beginner
            break;
        case "Intermediate":
            imagId = Images.Intermediate
            break;
        case "Advanced":
            imagId = Images.Advanced
            break;
        case "Master":
            imagId = Images.Master
            break;
        case "Expert":
            imagId = Images.Expert
            break;
        default:
            console.log("Invalid");
    }    

    return (
        <div id="levelContainer">
            <div id="badgeContainer">
                <img
                    src={`https://dev231407.service-now.com/${imagId}.iix`}
                    alt="Badge"
                />
            </div>
            <div id="ProgressbarContainer">
                {/* The fixed-width container */}
                <div
                    id="Progressbar"
                    style={{ width: "100%", height: "20px", backgroundColor: "#e0e0e0", borderRadius: "10px", position: "relative" }}
                >
                    {/* The dynamic filling */}
                    <div
                        style={{
                            width: `${progressBarWidth}%`,
                            height: "100%",
                            background: "linear-gradient(to right, #0a1128, #1282a2)",
                            borderRadius: "10px",
                            transition: "width 0.5s ease",
                        }}
                    ></div>
                </div>
                <div id="Percentage">{`${progressBarWidth.toFixed(1)}%`}</div>
            </div>
            <div id="DataContainer">
                <div id="Lable">
                    <div id="PointsLabel">Points:</div>
                </div>
                <div id="Values">
                    <div id="PointsValue">{TechnicianProfile ? TechnicianProfile.total_points : 0}</div>
                </div>
            </div>
        </div>
    );
};


createCustomElement("x-1522458-tech-level", {
	renderer: { type: snabbdom },
	view,
	styles: style,
	actionHandlers: {
		/* 
        1- get the sys_id from the url
        2- get the technician profile that technician.value = sys_id
        3- fill the array TechnicianProfiles
        4- write the logic of level percentage and progress bar
        */

		[COMPONENT_BOOTSTRAPPED]: (coeffects) => {
			const url = window.location.href;
			const technicianSysId = url.split("/").pop();

			const { dispatch } = coeffects;

			dispatch("FETCH_MY_Technician", {
				sysparm_query: "technician=" + technicianSysId,
			});
		},
		FETCH_MY_Technician: createHttpEffect(
			"api/now/table/x_1522458_automo_0_technician_profile",
			{
				method: "GET",
				queryParams: ["sysparm_query"],
				successActionType: "FETCH_MY_Technician_SUCCESS",
			}
		),
		FETCH_MY_Technician_SUCCESS: (coeffects) => {
			const { action, updateState } = coeffects;
			const { result } = action.payload;

			var TechnicianProfile = result[0];


            const levelValue = levelThreshold[TechnicianProfile.level];
            //console.log(levelValue);
            
            const progressBarWidth = (TechnicianProfile.total_points / levelValue) * 100;
            //console.log(progressBarWidth);
            

			//console.log(TechnicianProfile);

			updateState({ TechnicianProfile :TechnicianProfile, progressBarWidth:progressBarWidth });

			const { dispatch } = coeffects;

			dispatch("FETCH_IMAGES", {
				sysparm_query:
					"name=x_1522458_automo_0.beginner_1.png^ORname=x_1522458_automo_0.intermediate_1.png^ORname=x_1522458_automo_0.advanced_1.png^ORname=x_1522458_automo_0.master.png^ORname=x_1522458_automo_0.expert.png",
			});
		},
		FETCH_IMAGES: createHttpEffect("api/now/table/db_image", {
			method: "GET",
			queryParams: ["sysparm_query"],
			successActionType: "FETCH_IMAGES_SUCCESS",
		}),
		FETCH_IMAGES_SUCCESS: (coeffects) => {
			const { action, updateState, state } = coeffects;
			const { result } = action.payload;
            


			
			//console.log(state.TechnicianProfile.level);
		},
	},
});
