import { createCustomElement, actionTypes } from "@servicenow/ui-core";
import snabbdom from "@servicenow/ui-renderer-snabbdom";
import styles from "./styles.scss";
import style from "./Notification.scss";
import { createHttpEffect } from "@servicenow/ui-effect-http";
const { COMPONENT_BOOTSTRAPPED } = actionTypes;

const view = (state, { updateState }) => {
	const { MyNotification } = state;

	const toggleSidebarNot = (isOpen) => {
		updateState({ isSidebarOpen: isOpen });
	};

	// Function to close the sidebar
	const closeSidebar = () => {
		updateState({ isSidebarOpen: false });
	};

	const RedirectChat = (id) => {
		//alert("redirect to " + id);
		window.location.href = `https://dev231407.service-now.com/x/1522458/customer-support/chatting-page/params/chat-sys-id/${id}`;
		
	};

	return (
		<div className="All">
			{/* Sidebar */}
			<div className={`sidebar ${state.isSidebarOpen ? "open" : ""}`}>
				<div className="sidebar-content not">
					<h2 className="sidebar-header" style={{ textAlign: "center" }}>
						Notification
					</h2>
					<div className="sidebar-Body not">
									{Array.isArray(MyNotification) &&
									MyNotification.length > 0 ? (
										MyNotification.map((Notification, index) => (
											<div
												className="sidebar-card not"
												on-click={() => RedirectChat(Notification.sender.value)}
												key={index}
											>
												<div className="notification-content">
													You've got a new message from{" "}
													{Notification.sender_name}!
												</div>
											</div>
										))
									) : (
										<div className="loading-text">
											There is no notification available...
										</div>
									)}
								</div>
				</div>

				{/* Close Button */}
				<button className="close-sidebar" on-click={closeSidebar}>
					Close
				</button>
			</div>

			{/* Main content */}
			<div className="icon-container">
				<div className="icon-item" on-click={() => toggleSidebarNot(true)}>
					<img
						src="https://dev231407.service-now.com/d68ef90283071210cccd5d10feaad3c3.iix"
						alt="Notifications"
					/>
				</div>
			</div>
		</div>
	);
};

createCustomElement("x-1522458-notification-icon", {
	renderer: { type: snabbdom },
	view,
	styles: style,
	properties: {
		text: { default: "35cc6c08839b1210cccd5d10feaad3b6" },
	},
	actionHandlers: {
		[COMPONENT_BOOTSTRAPPED]: (coeffects) => {
			console.log("COMPONENT_BOOTSTRAPPED");
			const { dispatch, state } = coeffects;

			const ManaerID = state.properties.text;

			dispatch("FETCH_MY_NOTIFICATION", {
				sysparm_query: "seen=false^receiver.sys_id=" + ManaerID,
			});
		},
		FETCH_MY_NOTIFICATION: createHttpEffect(
			"api/now/table/x_1522458_automo_0_notification",
			{
				method: "GET",
				queryParams: ["sysparm_query"],
				successActionType: "FETCH_MY_NOTIFICATION_SUCCESS",
			}
		),
		FETCH_MY_NOTIFICATION_SUCCESS: (coeffects) => {
			console.log("FETCH_MY_NOTIFICATION_SUCCESS");

			const { action, updateState, state } = coeffects;
			const { result } = action.payload;

			const MyNotification = [...result];
			console.log(MyNotification);

			updateState({ MyNotification });
		},
	},
});
