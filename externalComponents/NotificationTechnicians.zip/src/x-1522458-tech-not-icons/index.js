import { createCustomElement, actionTypes } from "@servicenow/ui-core";
import snabbdom from "@servicenow/ui-renderer-snabbdom";
import styles from "./styles.scss";
import style from "./techNot.scss";
import { createHttpEffect } from "@servicenow/ui-effect-http";
const { COMPONENT_BOOTSTRAPPED } = actionTypes;

//let ManaerID = "803a7a3283429210cccd5d10feaad3d3";

const view = (state, { updateState }) => {
	//console.log(state);

	// Function to toggle sidebar visibility

	const { TheFinalRes } = state;
	const { MyNotification } = state;

	const toggleSidebarTech = (isOpen) => {
		updateState({ isSidebarOpen: isOpen });
		updateState({ TechClicked: isOpen });
		updateState({ NotClicked: !isOpen });
	};
	const toggleSidebarNot = (isOpen) => {
		updateState({ isSidebarOpen: isOpen });
		updateState({ TechClicked: !isOpen });
		updateState({ NotClicked: isOpen });
	};

	// Function to close the sidebar
	const closeSidebar = () => {
		updateState({ isSidebarOpen: false });
		updateState({ TechClicked: false });
		updateState({ NotClicked: false });
	};

	const Redirect = (id) => {
		window.location.href = `https://dev231407.service-now.com/x/1522458/service-manager-side/technician-profile/${id}`;
	};
	const RedirectChat = (id) => {
		//alert("redirect to " + id);
		window.location.href = `https://dev231407.service-now.com/x/1522458/service-manager-side/chat/params/chat-sys-id/${id}`;
	};

	return (
		<div className="All">
			{/* Sidebar */}
			<div className={`sidebar ${state.isSidebarOpen ? "open" : ""}`}>
				{(() => {
					if (state.TechClicked) {
						return (
							<div className="sidebar-content">
								<h2 className="sidebar-header" style={{ textAlign: "center" }}>
									My Technicians
								</h2>
								<div className="sidebar-Body">
									{Array.isArray(TheFinalRes) &&
										TheFinalRes.map((technician, index) => (
											<div
												className="sidebar-card"
												on-click={() => Redirect(technician.Userid)}
												key={index}
											>
												<div className="Avatar">
													<img
														src={`https://dev231407.service-now.com/${technician.image}.iix`}
														alt="Avatar"
													/>
												</div>
												<div className="Name">
													<h3>{technician.Name}</h3>
												</div>
											</div>
										))}
								</div>
							</div>
						);
					}
					if (state.NotClicked) {
						return (
							<div className="sidebar-content not">
								<h2 className="sidebar-header" style={{ textAlign: "center" }}>
									Notification
								</h2>
								<div className="sidebar-Body not">
									{Array.isArray(MyNotification) &&
									MyNotification.length > 0 ? (
										MyNotification.map((Notification, index) => (
											<div
												className="sidebar-card not"
												on-click={() => RedirectChat(Notification.sender.value)}
												key={index}
											>
												<div className="notification-content">
													You've got a new message from{" "}
													{Notification.sender_name}!
												</div>
											</div>
										))
									) : (
										<div className="loading-text">
											There is no notification available...
										</div>
									)}
								</div>
							</div>
						);
					}
				})()}

				{/* Close Button */}
				<button className="close-sidebar" on-click={closeSidebar}>
					Close
				</button>
			</div>

			{/* Main content */}
			<div className="icon-container">
				<div className="icon-item" on-click={() => toggleSidebarTech(true)}>
					<img
						src="https://dev231407.service-now.com/e6be390283071210cccd5d10feaad368.iix"
						alt="Technicians"
					/>
				</div>
				<div className="icon-item" on-click={() => toggleSidebarNot(true)}>
					<img
						src="https://dev231407.service-now.com/d68ef90283071210cccd5d10feaad3c3.iix"
						alt="Notifications"
					/>
				</div>
			</div>
		</div>
	);
};

createCustomElement("x-1522458-tech-not-icons", {
	renderer: { type: snabbdom },
	view,
	styles: style,
	properties: {
		text: { default: "803a7a3283429210cccd5d10feaad3d3" },
	},
	actionHandlers: {
		[COMPONENT_BOOTSTRAPPED]: (coeffects) => {
			console.log("COMPONENT_BOOTSTRAPPED");
			const { dispatch, state } = coeffects;

			const ManaerID = state.properties.text;

			dispatch("FETCH_MY_USER", {
				sysparm_query: "sys_id=" + ManaerID,
			});
		},
		FETCH_MY_USER: createHttpEffect("api/now/table/sys_user", {
			method: "GET",
			queryParams: ["sysparm_query"],
			successActionType: "FETCH_MY_USER_SUCCESS",
		}),
		FETCH_MY_USER_SUCCESS: (coeffects) => {
			console.log("FETCH_MY_USER_SUCCESS");
			const { action, updateState } = coeffects;
			const { result } = action.payload;

			var department = result[0].department.value;

			//console.log(result);

			const { dispatch } = coeffects;

			dispatch("FETCH_MY_TECHNICIANS", {
				sysparm_query: "department=" + department,
			});
		},
		FETCH_MY_TECHNICIANS: createHttpEffect(
			"api/now/table/x_1522458_automo_0_technician_profile",
			{
				method: "GET",
				queryParams: ["sysparm_query"],
				successActionType: "FETCH_MY_TECHNICIANS_SUCCESS",
			}
		),
		FETCH_MY_TECHNICIANS_SUCCESS: (coeffects) => {
			console.log("FETCH_MY_TECHNICIANS_SUCCESS");
			const { action, updateState } = coeffects;
			const { result } = action.payload;

			const MyTechnicians = [...result];

			//console.log(MyTechnicians);
			updateState({ MyTechnicians });

			var department = MyTechnicians[0].department.value;
			//console.log(MyTechnicians);

			const { dispatch } = coeffects;

			dispatch("FETCH_TECHNICIANS_NAMES", {
				sysparm_query: "department=" + department,
			});
		},
		FETCH_TECHNICIANS_NAMES: createHttpEffect("api/now/table/sys_user", {
			method: "GET",
			queryParams: ["sysparm_query"],
			successActionType: "FETCH_TECHNICIANS_NAMES_SUCCESS",
		}),
		FETCH_TECHNICIANS_NAMES_SUCCESS: (coeffects) => {
			console.log("FETCH_TECHNICIANS_NAMES_SUCCESS");

			const { action, updateState, state } = coeffects;
			const { result } = action.payload;

			const MyUSERS = [...result];
			//console.log(MyUSERS);

			const MyTechnicians = state.MyTechnicians;

			let TheFinalRes = [];

			MyTechnicians.forEach((technicianProfile) => {
				MyUSERS.forEach((user) => {
					if (user.sys_id === technicianProfile.technician.value) {
						TheFinalRes.push({
							Name: user.name,
							score: technicianProfile.monthly_score,
							image: user.photo,
							Userid: user.sys_id,
						});
					}
				});
			});

			TheFinalRes.sort((a, b) => b.score - a.score);

			//console.log(TheFinalRes);

			updateState({ TheFinalRes });

			const { dispatch } = coeffects;
			console.log("Before FETCH_MY_NOTIFICATION ");

			dispatch("FETCH_MY_NOTIFICATION", {
				sysparm_query:
					"receiver.sys_id=" + state.properties.text + "^seen=false",
			});

			console.log("After FETCH_MY_NOTIFICATION ");
		},
		FETCH_MY_NOTIFICATION: createHttpEffect(
			"api/now/table/x_1522458_automo_0_notification",
			{
				method: "GET",
				queryParams: ["sysparm_query"],
				successActionType: "FETCH_MY_NOTIFICATION_SUCCESS",
			}
		),
		FETCH_MY_NOTIFICATION_SUCCESS: (coeffects) => {
			console.log("FETCH_MY_NOTIFICATION_SUCCESS");

			const { action, updateState, state } = coeffects;
			const { result } = action.payload;

			const MyNotification = [...result];
			console.log(MyNotification);

			updateState({ MyNotification });
		},
	},
});
