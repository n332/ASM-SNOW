import { createHttpEffect } from "@servicenow/ui-effect-http";
import { createCustomElement, actionTypes } from "@servicenow/ui-core";
const { COMPONENT_BOOTSTRAPPED } = actionTypes;
import snabbdom from "@servicenow/ui-renderer-snabbdom";
import styles from "./styles.scss";
import style from "./barChart.scss";

const url = window.location.href;
const technicianSysId = url.split("/").pop();

const months = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec",
];

const title = "Bar Chart";

const DefaultFelter = "last 12 month";

const getFilterOptions = (Data) => {
	let filterOptions = [];

	let firstYear = new Date(Data[0].year, 0).getFullYear();
	let lastYear = new Date(Data[Data.length - 1].year, 0).getFullYear();

	let allYears = [];
	for (let year = firstYear; year <= lastYear; year++) {
		allYears.push(year);
	}

	filterOptions.push("last 12 month");

	for (let i = 0; i < allYears.length; i++) {
		filterOptions.push(allYears[i]);
	}

	return filterOptions;
};

const GetLastTwelveMonths = (Data) => {
	// get the current month and year
	let currentMonth = Number(new Date().getMonth());
	let currentYear = new Date().getFullYear();

	// filter the data
	let filterdData = [];
	for (var i = currentMonth - 1; i > currentMonth - 12 - 1; i--) {
		if (i < 0) {
			let m = months[Number(i) + 12];
			let y = currentYear - 1;

			let filtered = Data.filter(
				(item) => item.year === y.toString() && item.label === m
			);

			filterdData = filterdData.concat(filtered);
		} else {
			let m = months[i];
			let y = currentYear;

			let filtered = Data.filter(
				(item) => item.year === y.toString() && item.label === m
			);

			filterdData = filterdData.concat(filtered);
		}
	}

	// sort the data
	filterdData.sort((a, b) => {
		let monthIndexA = months.indexOf(a.label);
		let monthIndexB = months.indexOf(b.label);

		return monthIndexA - monthIndexB;
	});

	filterdData.sort((a, b) => a.year - b.year);

	return filterdData;
};

const GetDataByMonth = (F, Data) => {
	return Data.filter((item) => item.year === F.toString());
};

const FilterTheData = (F, Data) => {
	if (F === "last 12 month") {
		return GetLastTwelveMonths(Data);
	} else {
		return GetDataByMonth(F, Data);
	}
};

const view = (state, { updateState }) => {
	// Ensure the default filter is set initially
	if (!state.Currentfilter) {
		updateState({ Currentfilter: DefaultFelter });
	}

	const handleFilterChange = (option) => {
		if (state.DataFromServer) {
			updateState({ Currentfilter: option });
			updateState({ CurrentData: FilterTheData(option, state.DataFromServer) });
		}
	};

	// Default filter options and data
	let filterOptions = ["last 12 month"];
	let DefaultData = [];

	if (state.DataFromServer) {
		DefaultData = GetLastTwelveMonths(state.DataFromServer);
		filterOptions = getFilterOptions(state.DataFromServer);
	}

	return (
		<div className="container">
			<h3 className="header">{state.properties.text}</h3>
			<div className="filter-buttons">
				{filterOptions.map((option, index) => (
					<button
						key={index}
						className={`filter-button ${
							state.Currentfilter === option ? "active" : ""
						}`}
						on-click={() => handleFilterChange(option)}
					>
						{option}
					</button>
				))}
			</div>

			<div className="simple-bar-chart">
				{state.CurrentData && state.CurrentData.length > 0
					? state.CurrentData.map((item, index) => (
							<div
								className="item"
								key={index}
								style={{
									"--clr": "#034078",
									"--val": item.value,
								}}
							>
								<div className="label">{item.label + item.year.slice(-2)}</div>
								<div className="value">{(item.value * 100).toFixed(0)}%</div>
							</div>
					  ))
					: DefaultData.map((item, index) => (
							<div
								className="item"
								key={index}
								style={{
									"--clr": "#034078",
									"--val": item.value,
								}}
							>
								<div className="label">{item.label + item.year.slice(-2)}</div>
								<div className="value">{(item.value * 100).toFixed(0)}%</div>
							</div>
					  ))}
			</div>
		</div>
	);
};


createCustomElement("x-1522458-bar-chart", {
	renderer: { type: snabbdom },
	view,
	styles: style,
	properties: {
        text: {default: 'Bar Chart'}
    },
	actionHandlers: {
		[COMPONENT_BOOTSTRAPPED]: (coeffects) => {
			const { dispatch } = coeffects;

			dispatch("FETCH_DATA", {
				sysparm_query: "technician.sys_id=" + technicianSysId,
			});
		},
		FETCH_DATA: createHttpEffect(
			"api/now/table/x_1522458_automo_0_technician_profile",
			{
				method: "GET",
				queryParams: ["sysparm_query"],
				successActionType: "FETCH_DATA_SUCCESS",
			}
		),
		FETCH_DATA_SUCCESS: (coeffects) => {
			const { action, updateState, state } = coeffects;
			const { result } = action.payload;

			let dataOBJ = result[0].performance_history;

			dataOBJ = JSON.parse(dataOBJ);

			let DataFromServer = [];
			DataFromServer = [...dataOBJ.data];

			updateState({ DataFromServer });
		},
	},
});
