import './x-1522458-bar-chart';
