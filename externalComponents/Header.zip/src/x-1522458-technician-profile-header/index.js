import { createHttpEffect } from "@servicenow/ui-effect-http";
import { createCustomElement, actionTypes } from "@servicenow/ui-core";
import snabbdom from "@servicenow/ui-renderer-snabbdom";
import styles from "./styles.scss";
import style from "./sidebar.scss";
const { COMPONENT_BOOTSTRAPPED } = actionTypes;

const url = window.location.href;
const technicianSysId = url.split("/").pop();

const Redirect = () => {
	window.location.href = `https://dev231407.service-now.com/x/1522458/service-manager-side/chat/params/chat-sys-id/${technicianSysId}`;
};


const view = (state, { updateState }) => {
	console.log(state);
	return (
		<div className="Sidebar">
			<div className="ImageContainer">
				<img
					src={`https://dev231407.service-now.com/${state.photo}.iix`}
					alt={"Technician's Image"}
				></img>
			</div>
			<div className="NameContainer">
				<h1>{state.name}</h1>
			</div>
			<div className="ContactInfo">
				<div className="Phone"> Phone: 0 114 xxx xxxx</div>
				<div className="Email"> Email: example@gmail.com</div>
			</div>

			{/* New Upcoming Tasks Section */}
			<div className="UpcomingTasks">
				<h2>Upcoming Tasks</h2>
				<ul>
					{/* Dynamically render tasks */}
					{state.TasksArr && state.TasksArr.length > 0 ? (
						state.TasksArr.map((task, index) => (
							<li key={index}>
								{task.number}: {task.short_description}
							</li>
						))
					) : (
						<li>No upcoming tasks</li>
					)}
				</ul>
			</div>

			<div className="buttonContainer">
				<button on-click={() => Redirect()}>Send a message</button>
			</div>
		</div>
	);
};


createCustomElement("x-1522458-technician-profile-header", {
	renderer: { type: snabbdom },
	view,
	styles: style,
	actionHandlers: {
		[COMPONENT_BOOTSTRAPPED]: (coeffects) => {
			const { dispatch } = coeffects;

			dispatch("FETCH_MY_USER", {
				sysparm_query: "sys_id=" + technicianSysId,
			});
		},
		FETCH_MY_USER: createHttpEffect("api/now/table/sys_user", {
			method: "GET",
			queryParams: ["sysparm_query"],
			successActionType: "FETCH_MY_USER_SUCCESS",
		}),
		FETCH_MY_USER_SUCCESS: (coeffects) => {
			const { action, updateState, state } = coeffects;
			const { result } = action.payload;

			let MyUser = [...result];
			updateState({ name: MyUser[0].name });
			updateState({ photo: MyUser[0].photo });

			const { dispatch } = coeffects;

			dispatch("FETCH_TECH_TASKS", {
				sysparm_limit: '4',
				sysparm_query: "state=scheduled^assined_to=" + technicianSysId,
			});
		},
		FETCH_TECH_TASKS: createHttpEffect(
			"api/now/table/x_1522458_automo_0_task",
			{
				method: "GET",
				queryParams: ["sysparm_query","sysparm_limit"],
				successActionType: "FETCH_TECH_TASKS_SUCCESS",
			}
		),
		FETCH_TECH_TASKS_SUCCESS: (coeffects) => {
			const { action, updateState, state } = coeffects;
			const { result } = action.payload;

			let MyTasks = [...result];

			let TasksArr = [];

			MyTasks.forEach((task) => {
				
				TasksArr.push({
					number: task.number,
					short_description: task.short_description,
				});
			});

			updateState({TasksArr})

		},
	},
});
