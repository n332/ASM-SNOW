import { createHttpEffect } from "@servicenow/ui-effect-http";
import { createCustomElement, actionTypes } from "@servicenow/ui-core";
const { COMPONENT_BOOTSTRAPPED } = actionTypes;
import snabbdom from "@servicenow/ui-renderer-snabbdom";
import styles from "./styles.scss";

const url = window.location.href;
const technicianSysId = url.split("/").pop();

const view = (state, { updateState }) => {
    // Provide a fallback value for `data` if `state.uniqueValues` is undefined
    const data = state.uniqueValues || [];

    console.log(state);
    

    // Avoid calculations if `data` is empty
    if (data.length === 0) {
        return (
            <div className="container" style={{ height: state.properties.widgetH }}>
                <h3 className="header">{state.properties.header}</h3>
                <p>Loading data...</p>
            </div>
        );
    }

    const total = data.reduce((sum, item) => sum + item.value, 0);

    const allColors = ["#4A9BD6", "#9ECBE1", "#1282A2"];
    const colors = allColors.slice(0, data.length);

    let cumulativePercent = 0;
    const segments = data.map((item, index) => {
        const valuePercent = item.value / total;
        const startPercent = cumulativePercent * 100;
        const endPercent = (cumulativePercent + valuePercent) * 100;
        cumulativePercent += valuePercent;

        return {
            ...item,
            startPercent,
            endPercent,
            color: colors[index],
        };
    });

    const gradientBackground = segments
        .map(
            (segment) =>
                `${segment.color} ${segment.startPercent}% ${segment.endPercent}%`
        )
        .join(", ");
    
        const Redirect = (label) => {
            window.location.href = `https://dev231407.service-now.com/x/1522458/service-manager-side/technician-s-tasks/${technicianSysId}/${state.properties.requiredfield}/${label}`;
        };

    return (
        <div className="container" style={{ height: state.properties.widgetH }}>
            <h3 className="header">{state.properties.header}</h3>

            <div className="pie-chart-container">
                <div
                    className="pie-chart"
                    style={{
                        background: `conic-gradient(${gradientBackground})`,
                    }}
                ></div>
                <div className="key-container">
                    {segments.map((segment, index) => (
                        <div key={index} className="key-item">
                            <div
                                className="key-color-box"
                                on-click={() => Redirect(segment.label)}
                                style={{ backgroundColor: segment.color }}
                            ></div>
                            <span style={{ fontSize: "10px" }}>
                                {segment.name} {`[${Math.round(segment.value * 100) / 100}%]`}
                            </span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};





createCustomElement("x-1522458-task-percentage", {
	renderer: { type: snabbdom },
	view,
	styles,
	properties: {
		header: { default: "Pie Chart" },
		query: { default: "assined_to.sys_id=0949b63283429210cccd5d10feaad37f" },
		requiredfield: { default: "insoection" },
		widgetH: {default:"350px"},
	},
	actionHandlers: {
		[COMPONENT_BOOTSTRAPPED]: (coeffects) => {
			const { dispatch,state} = coeffects;

            var query = "assined_to.sys_id="+technicianSysId;
            if (state.properties.requiredfield === "state"){
                query = query + "^state=scheduled^ORstate=in_progress"
            }

			dispatch("FETCH_DATA", {
				sysparm_query: query,
			});
		},
		FETCH_DATA: createHttpEffect(`api/now/table/x_1522458_automo_0_task`, {
			method: "GET",
			queryParams: ["sysparm_query"],
			successActionType: "FETCH_DATA_SUCCESS",
		}),
		FETCH_DATA_SUCCESS: (coeffects) => {
			const { action, updateState , state} = coeffects;
			const { result } = action.payload;

            //console.log(result);
            

			let FeildArr = [];

			result.forEach((element) => {
				FeildArr.push(element[state.properties.requiredfield]);
			});

			let uniqueValues = [...new Set(FeildArr)];

			uniqueValues = uniqueValues.map((value) => ({
				name: value,
                label:value,
				value: 0,
			}));

			uniqueValues.forEach((val) => {
				FeildArr.forEach((element) => {
					if (element === val.name) {
						val.value++;
					}

					
				});
				val.value = (val.value/FeildArr.length)*100
                val.name = val.name === "true" ? "inspection" : val.name === "false" ? "repair" : val.name
			});

            console.log(uniqueValues);
            //console.log(state.properties.query);
            

			updateState({ uniqueValues });
		},
	},
});
