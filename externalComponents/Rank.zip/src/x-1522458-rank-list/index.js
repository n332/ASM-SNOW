import { createCustomElement, actionTypes } from "@servicenow/ui-core";
import snabbdom from "@servicenow/ui-renderer-snabbdom";
import styles from "./styles.scss";
import style from "./rankList.scss";
import { createHttpEffect } from "@servicenow/ui-effect-http";
const { COMPONENT_BOOTSTRAPPED } = actionTypes;

const view = (state, { updateState }) => {
    // Get TheFinalRes from the state
    const { TheFinalRes } = state;

    return (
        <div id="rankList">
            <div id="headerContainer">
                <div id="header">
                    <h1>Monthly Ranking</h1>
                </div>
            </div>
            <div id="contentContainer">
                {TheFinalRes && TheFinalRes.length > 0 ? (
                    TheFinalRes.map((technician, index) => (
                        <div id="card" key={index}>
                            <div id="number">{index + 1}</div>
                            <div id="avatar">
                                {/* Check if image exists */}
                                {technician.image ? (
                                    <img
                                        src={`https://dev231407.service-now.com/${technician.image}.iix`}
                                        alt="Technician Avatar"
                                    />
                                ) : (
                                    <div>No Image Available</div>
                                )}
                            </div>
                            <div id="nameScore">
                                <div id="name">{technician.Name}</div>
                                <div id="scoreContainer">
                                    <div id="scoreHeader" style={{ color: "white" }}>Score</div>
                                    <div id="scoreValue">{technician.score}</div>
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <div>No technicians available</div>
                )}
            </div>
        </div>
    );
};

createCustomElement("x-1522458-rank-list", {
    renderer: { type: snabbdom },
    view,
    styles: [style, styles],
    actionHandlers: {
		/*
		1- get the sys_id from the url
		2- get all the technician profiles with the department = sys_id departmnet
		3- for each technician profile
			A- get the technician.sys_id
			B- get the user name of this technician
		4- fill the array: technicianProfileData [ {name: <technicianName}, MonthlyScore: <MonthlyScore>]
		*/
		[COMPONENT_BOOTSTRAPPED]: (coeffects) => {
			const url = window.location.href;
			const technicianSysId = url.split("/").pop();

			const { dispatch } = coeffects;

			dispatch("FETCH_MY_USER", {
				sysparm_query: "sys_id=" + technicianSysId,
			});
		},
		FETCH_MY_USER: createHttpEffect("api/now/table/sys_user", {
			method: "GET",
			queryParams: ["sysparm_query"],
			successActionType: "FETCH_MY_USER_SUCCESS",
		}),
		FETCH_MY_USER_SUCCESS: (coeffects) => {
			const { action, updateState } = coeffects;
			const { result } = action.payload;

			let MyUser = [...result];

			let Department = MyUser[0].department.value;
			const { dispatch } = coeffects;

			dispatch("FETCH_Technician_Profiles", {
				sysparm_query: "department=" + Department,
			});
		},
		FETCH_Technician_Profiles: createHttpEffect(
			"api/now/table/x_1522458_automo_0_technician_profile",
			{
				method: "GET",
				queryParams: ["sysparm_query"],
				successActionType: "FETCH_Technician_Profiles_SUCCESS",
			}
		),
		FETCH_Technician_Profiles_SUCCESS: (coeffects) => {
			const { action, updateState } = coeffects;
			const { result } = action.payload;

			var TechnicianProfiles = [...result];

			updateState({ TechnicianProfiles });

			var query = "";

			TechnicianProfiles.forEach(function (element) {
				query += "sys_id=" + element.technician.value + "^OR";
			});
			query = query.slice(0, -3);

			const { dispatch } = coeffects;

			dispatch("FETCH_USERS", {
				sysparm_query: query,
			});
		},
		FETCH_USERS: createHttpEffect("api/now/table/sys_user", {
			method: "GET",
			queryParams: ["sysparm_query"],
			successActionType: "FETCH_USERS_SUCCESS",
		}),
		FETCH_USERS_SUCCESS: (coeffects) => {
			const { action, updateState, state } = coeffects;
			const { result } = action.payload;

			let USERS = [...result];
            //console.log(USERS);

			const TechnicianProfiles = state.TechnicianProfiles;

			let TheFinalRes = [];

			TechnicianProfiles.forEach((technicianProfile) => {
				USERS.forEach((user) => {
					if (user.sys_id === technicianProfile.technician.value) {
						TheFinalRes.push({
							Name: user.name,
							score: technicianProfile.monthly_score,
                            image: user.photo
						});
					}
				});
			});

			TheFinalRes.sort((a, b) => b.score - a.score);

			console.log(TheFinalRes);

			updateState({TheFinalRes})
			
		},
	},

});
